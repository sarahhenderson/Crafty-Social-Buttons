<p><strong>Credits</strong></p>

<p>I owe thanks to the following people for the existence of this plugin:</p>
<p>Thanks are due to the lovely people who make beautiful icons and other resources freely available:</p>
<ul>
    <li><a href="http://arbent.net/blog/social-media-circles-icon-set">Arbenting icons from Angie Bowen</a></li>
    <li>(The Crafty Stitchy icon sets were made my me)</li>                
    <li><a href="http://creativenerds.co.uk/freebies/metal-social-media-free-icon-set/">Metal icons from Creative Nerds</a></li>
    <li><a href="http://www.productivedreams.com/page-peel-free-social-iconset/">PagePeel icons by Gopal Raju</a></li>
    <li><a href="http://www.designbolts.com/2012/09/19/beautiful-ribbon-social-media-icons-pack/">Ribbon icons from Design Bolts</a></li>
    <li><a href="http://simpleicons.org/">Simple icons from Dan Leech</a></li>
    <li><a href="http://vervex.deviantart.com/art/Somacro-40-300DPI-Social-Media-Icons-267955425">Somacro icons from vervex</a></li>
    <li>Tom McFarlin for his useful <a href="https://github.com/tommcfarlin/WordPress-Plugin-Boilerplate">Wordpress Plugin Boilerplate</a></li>
    <li>David Neal for his <a href="http://wordpress.org/plugins/simple-share-buttons-adder/">
    Social Share Buttons Adder</a>, which provided both inspiration and technical insight. </li>
    <li>Curt Smith for the <a href="http://www.flickr.com/photos/curtsm/4759462052/">WordPress.org Plugin Repository Banner image</a></li>
</ul>