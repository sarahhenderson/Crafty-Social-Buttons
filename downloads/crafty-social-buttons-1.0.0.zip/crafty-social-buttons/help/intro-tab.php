<p><strong>Welcome to Crafty Social Buttons</strong></p>

<p>If you are looking for more information about how to use this plugin, and what all the options do, please use the tabs on the left.</p>

<p>For even more information (and probably an easier-to-read format), please visit 
<a href="http://sarahhenderson.github.io/Crafty-Social-Buttons">the plugin's website.</a>

<p>I really hope you find this plugin useful. Please don't hesitate to <a href="mailto:sarah@sarahhenderson.info">contact me</a> with any issues you have, or any requests for new features.</p>