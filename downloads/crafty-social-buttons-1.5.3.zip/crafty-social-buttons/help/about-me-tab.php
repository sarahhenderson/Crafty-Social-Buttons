<p><strong>About Me</strong></p>

<p>Made with love by <a href="http://sarahhenderson.info">Sarah Henderson</a>,
	a freelance web developer from New Zealand.</p>
<p>I learned to crochet and thought of starting up a crochet related blog to show
	off my new creations.  I got a bit sidetracked making pretty icons and WordPress plugins
	and thought that others in the crafty community might want to use them too.</p>
<p>I never did get around to blogging about crochet!</p>

<p>For more information about this plugin, please visit 
<a href="http://sarahhenderson.github.io/Crafty-Social-Buttons">the plugin's website.</a>
</p>

<p>I really hope you find this plugin useful. Please don't hesitate to
	<a href="mailto:sarah@sarahhenderson.info">contact me</a> with any issues you have,
	or any requests for new features.  If you want to contribute towards its further
	development, (or you just want to say thank you), you can
	<a href="http://sarahhenderson.info/buy-me-a-coffee">buy me a coffee</a>.
</p>